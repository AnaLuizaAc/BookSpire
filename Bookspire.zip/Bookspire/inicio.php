<?php

include ('config.php');

?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="inicio2.css">
    <link rel="stylesheet"
    href="https://cdn.jsdelivr.net/npm/boxicons@latest/css/boxicons.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css">
    <title>BookSpire</title>
    <style>
        .main-header{
            width: 75%;
            margin: auto;
            height: 80vh;
            display: flex;
            align-items: center;
            justify-content: space-around;
        }
        .main-header h5{
            font-size: 22px;
            color: white;
            font-weight: 550;

            
        }
        .main-header h2{
            font-size: 48px;
            width: 340px;
            margin-top: 10px;
            margin-bottom: 5px;
            color: white;
            
        }
        .main-header p{
            margin-bottom: 60px;
            color: white;
            

        }
        .main-header .btn{
            background: orange;
            border: 1px solid orange;
            font-size: 24px;
            color: white;
            font-weight: 400;
            padding: 12px 30px;
            border-radius: 50px;
            transition: all .5s;
        }
        .main-header .btn:hover{
            color: rgb(223, 119, 0);
            background: #ffffff;
        }
        .main-header img{
            width: 300px;
            height: auto;
            

        }

    </style>
</head>
<body>

<header>
        <a href="inicio.php" class="logo">
            <img src="BookSpireLogo333-removebg-preview.png" alt="#"> BookSpire
        </a>
        <ul class="navbar">
            <li><a href="inicio.php" class="home-active">Início</a></li>
            <li><a href="categorias.html">Categorias</a></li>
            <li><a href="perfil.php">Perfil</a></li>
            <li><a href="sobre.html">Sobre Nós</a></li></ul>

            
    </header>

    <div class="main-header">
    <div class="header">
    <h5>BookSpire biblioteca online</h5>
        <h2>Livros para alma vibrar</h2>
        <p>Só aqui você encontra os melhores livros de todos os gêneros para todas as idades!</p>

        <a href="categorias.html" class="btn">Ver Mais</a>
    </div>

    <img src="familia_livro.png" alt="">
 </div>


    
 


</body>
</html>