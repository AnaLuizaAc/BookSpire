<?php
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "bookspiredb";

    $conn = new mysqli($servername, $username, $password, $dbname );

    if($conn -> connect_error){
        die("deu erro". $conn -> connect_error);
    }

?>