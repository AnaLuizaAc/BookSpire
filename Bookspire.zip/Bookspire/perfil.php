<?php

include ('config.php');

?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="perfil.css">
    <link rel="stylesheet" href="inicio2.css">
    <link rel="stylesheet"
    href="https://cdn.jsdelivr.net/npm/boxicons@latest/css/boxicons.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css" />
    <title>BookSpire</title>
</head>
<body>
    <header>
        <a href="#" class="logo">
            <img src="BookSpireLogo333-removebg-preview.png" alt="#"> BookSpire
        </a>
        <ul class="navbar">
            <li><a href="inicio.php" class="home-active">Início</a></li>
            <li><a href="categorias.html">Categorias</a></li>
            <li><a href="perfil.php">Perfil</a></li>
            <li><a href="sobre.html">Sobre Nós</a></li>
        </ul>
        
    </header>

    <div class="wrapper">
        <form method="POST" action="cad.php">  
            <h1>login</h1>
            <div class="input-box">
                <input type="text" placeholder="username" name = "usuario"
                required>
                <i class='bx bxs-user'></i>
            </div>
            <div class="input-box">
                <input type="password" 
                placeholder="password" name = "senha"
                required>
                <i class="bx bxs-lock-alt"></i>
                </div>

                <div class="remember-forgot">
                    <label> <input type="checkbox"> Lembrar de Mim </label>
                    <a href="#">Esqueceu a Senha? </a>
                </div>

                <button  type = "submit" class="btn">Login</button>

                <div class="register-link">
                    <p>Não tem uma conta? <a href="cad.php"> Cadastre-se </a></p>
                </div>
                <div class="register-link">
                    <a href="inicio.php">Voltar ao Início</a>
                </div>
        </form>
    </div>

      
    
   
</body>
</html>